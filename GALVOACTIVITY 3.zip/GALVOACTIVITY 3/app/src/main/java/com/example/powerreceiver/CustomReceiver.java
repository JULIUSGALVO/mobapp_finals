package com.example.powerreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

// Add this import statement


public class CustomReceiver extends BroadcastReceiver {

    private static final String ACTION_CUSTOM_BROADCAST =
            "com.example.powerreceiver.ACTION_CUSTOM_BROADCAST";



    @Override
    public void onReceive(Context context, Intent intent) {
        String intentAction = intent.getAction();

        if (intentAction != null) {
            String toastMessage = "unknown intent action";

            if (Intent.ACTION_POWER_CONNECTED.equals(intentAction)) {
                toastMessage = "Power connected!";
            } else if (Intent.ACTION_POWER_DISCONNECTED.equals(intentAction)) {
                toastMessage = "Power disconnected!";
            } else if (ACTION_CUSTOM_BROADCAST.equals(intentAction)) {
                toastMessage = "Custom Broadcast Received";
            }

            Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show();
        }
    }

}