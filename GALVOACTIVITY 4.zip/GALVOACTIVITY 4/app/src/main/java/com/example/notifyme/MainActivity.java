package com.example.notifyme;

import static androidx.core.content.ContextCompat.getSystemService;
import static androidx.core.content.ContextCompat.registerReceiver;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class MainActivity extends AppCompatActivity {

    private static final String PRIMARY_CHANNEL_ID = "primary_notification_channel";
    private static final int NOTIFICATION_ID = 0;
    private static final String ACTION_UPDATE_NOTIFICATION =
            "com.example.notifyme.ACTION_UPDATE_NOTIFICATION";

    private NotificationManager mNotifyManager;
    private Button notifyButton, updateButton, cancelButton;
    private NotificationReceiver mReceiver = new NotificationReceiver();

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Hook up buttons
        notifyButton = findViewById(R.id.notify);
        updateButton = findViewById(R.id.update);
        cancelButton = findViewById(R.id.cancel);

        notifyButton.setOnClickListener(v -> sendNotification());
        updateButton.setOnClickListener(v -> updateNotification());
        cancelButton.setOnClickListener(v -> cancelNotification());

        // Register BroadcastReceiver for the “Update” action
        registerReceiver(mReceiver, new IntentFilter(ACTION_UPDATE_NOTIFICATION));

        // Create channel & initialize NotificationManager
        createNotificationChannel();

        // Initial button state: only “Notify” enabled
        setNotificationButtonState(true, false, false);
    }

    @Override
    protected void onDestroy() {
        // Don’t forget to unregister your receiver!
        unregisterReceiver(mReceiver);
        super.onDestroy();
    }

    private void createNotificationChannel() {
        mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Only create channel on Oreo+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    PRIMARY_CHANNEL_ID,
                    "Mascot Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            channel.setDescription("Notifications from the Notify Me! app");

            mNotifyManager.createNotificationChannel(channel);
        }
    }

    private NotificationCompat.Builder getNotificationBuilder() {
        // Intent to launch MainActivity when notification is tapped
        Intent notifyIntent = new Intent(this, MainActivity.class);
        PendingIntent notifyPendingIntent = PendingIntent.getActivity(
                this,
                NOTIFICATION_ID,
                notifyIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Intent to fire the update action
        Intent updateIntent = new Intent(ACTION_UPDATE_NOTIFICATION);
        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(
                this,
                NOTIFICATION_ID,
                updateIntent,
                PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, PRIMARY_CHANNEL_ID)
                .setContentTitle("You've been notified!")
                .setContentText("This is your notification text.")
                .setSmallIcon(R.drawable.ic_android)
                .setContentIntent(notifyPendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .addAction(R.drawable.ic_update, "Update Notification", updatePendingIntent);
    }

    public void sendNotification() {
        NotificationCompat.Builder builder = getNotificationBuilder();
        mNotifyManager.notify(NOTIFICATION_ID, builder.build());
        setNotificationButtonState(false, true, true);
    }

    public void updateNotification() {
        NotificationCompat.Builder builder = getNotificationBuilder()
                .setStyle(new NotificationCompat.BigPictureStyle()
                        .bigPicture(BitmapFactory.decodeResource(
                                getResources(), R.drawable.mascot_1))
                        .setBigContentTitle("Notification Updated!"));

        mNotifyManager.notify(NOTIFICATION_ID, builder.build());
        setNotificationButtonState(false, false, true);
    }

    public void cancelNotification() {
        mNotifyManager.cancel(NOTIFICATION_ID);
        setNotificationButtonState(true, false, false);
    }

    private void setNotificationButtonState(
            boolean notifyEnabled,
            boolean updateEnabled,
            boolean cancelEnabled
    ) {
        notifyButton.setEnabled(notifyEnabled);
        updateButton.setEnabled(updateEnabled);
        cancelButton.setEnabled(cancelEnabled);
    }

    // Inner BroadcastReceiver to handle “Update Notification” action
    public class NotificationReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateNotification();
        }
    }
}
